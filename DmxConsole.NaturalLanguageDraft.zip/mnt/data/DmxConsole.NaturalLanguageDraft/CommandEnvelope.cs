namespace DmxConsole.NaturalLanguageDraft;

public enum NlActionType
{
    SelectTarget,
    AdjustAttribute,
    SetAttribute,
    StoreCue,
    SetCueTiming,
    Undo,
    Redo,
    Batch
}

public enum NlAttribute
{
    Intensity,
    Position,
    Color,
    Beam
}

public enum AdjustmentMode
{
    Absolute,
    Relative
}

public sealed record TargetReference(
    Guid? StableId = null,
    string? CanonicalName = null,
    string? SpokenText = null,
    IReadOnlyList<Guid>? FixtureIds = null);

public sealed record ConsoleCommandEnvelope
{
    public required NlActionType Action { get; init; }
    public TargetReference? Target { get; init; }
    public NlAttribute? Attribute { get; init; }
    public AdjustmentMode? Mode { get; init; }
    public double? ValuePercent { get; init; }
    public decimal? CueNumber { get; init; }
    public double? FadeInSeconds { get; init; }
    public double? FadeOutSeconds { get; init; }
    public IReadOnlyList<ConsoleCommandEnvelope> Children { get; init; } = Array.Empty<ConsoleCommandEnvelope>();
    public string? SourceUtterance { get; init; }
}
