namespace DmxConsole.NaturalLanguageDraft;

/// <summary>
/// Seed vocabulary only. Show-specific group names always outrank this lexicon.
/// </summary>
public static class LightingLexicon
{
    public static readonly IReadOnlyDictionary<string, string> CanonicalAliases =
        new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["פרונטים"] = "Fronts",
            ["פרונט"] = "Fronts",
            ["fronts"] = "Fronts",
            ["ווש קר"] = "Cold Wash",
            ["שטיפה קרה"] = "Cold Wash",
            ["שטיפה אחורית קרה"] = "Cold Back Wash",
            ["ווש חם"] = "Warm Wash",
            ["בק לייט"] = "Backlight",
            ["בק"] = "Backlight",
            ["ספיישל"] = "Special",
            ["ספיישלים"] = "Specials",
            ["בומים"] = "Booms",
            ["רצפה"] = "Floor"
        };

    public static readonly IReadOnlyDictionary<string, NlAttribute> AttributeAliases =
        new Dictionary<string, NlAttribute>(StringComparer.OrdinalIgnoreCase)
        {
            ["אינטנסיטי"] = NlAttribute.Intensity,
            ["עוצמה"] = NlAttribute.Intensity,
            ["דימר"] = NlAttribute.Intensity,
            ["פוזישן"] = NlAttribute.Position,
            ["מיקום"] = NlAttribute.Position,
            ["צבע"] = NlAttribute.Color,
            ["בים"] = NlAttribute.Beam,
            ["אלומה"] = NlAttribute.Beam
        };
}
