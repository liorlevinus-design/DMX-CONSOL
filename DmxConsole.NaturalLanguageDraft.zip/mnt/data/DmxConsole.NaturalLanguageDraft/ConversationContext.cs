namespace DmxConsole.NaturalLanguageDraft;

/// <summary>
/// Language-layer context only. This must never become the source of truth for console state.
/// Console state lives in DmxConsole.Application/Core.
/// </summary>
public sealed class ConversationContext
{
    public TargetReference? LastResolvedTarget { get; set; }
    public NlAttribute? LastAttribute { get; set; }
    public AdjustmentMode? LastAdjustmentMode { get; set; }
    public double? LastNumericValue { get; set; }
    public IReadOnlyList<TargetCandidate> PendingCandidates { get; set; } = Array.Empty<TargetCandidate>();
    public string? PendingUtterance { get; set; }

    public void ClearAmbiguity()
    {
        PendingCandidates = Array.Empty<TargetCandidate>();
        PendingUtterance = null;
    }
}

public sealed record TargetCandidate(Guid StableId, string CanonicalName, string Kind, double Score = 1.0);
