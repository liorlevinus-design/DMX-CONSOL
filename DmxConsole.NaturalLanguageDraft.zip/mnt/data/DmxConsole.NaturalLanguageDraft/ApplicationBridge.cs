namespace DmxConsole.NaturalLanguageDraft;

/// <summary>
/// Boundary that the future NL project expects from DmxConsole.Application.
/// Implement this as an adapter over GroupService / SelectionService / CommandDispatcher.
/// No DMX/Core access belongs here.
/// </summary>
public interface IConsoleApplicationBridge
{
    Task<IReadOnlyList<TargetCandidate>> SearchTargetsAsync(string text, CancellationToken cancellationToken = default);
    Task<ApplicationExecutionResult> ExecuteAsync(IReadOnlyList<ConsoleCommandEnvelope> commands, CancellationToken cancellationToken = default);
    Task<ApplicationExecutionResult> UndoAsync(CancellationToken cancellationToken = default);
    Task<ApplicationExecutionResult> RedoAsync(CancellationToken cancellationToken = default);
}

public sealed record ApplicationOperationResult(
    string ActionType,
    bool Success,
    IReadOnlyList<Guid> AffectedFixtureIds,
    IReadOnlyDictionary<string, object?> Data,
    string? Error = null,
    string? Warning = null);

public sealed record ApplicationExecutionResult(
    bool Success,
    IReadOnlyList<ApplicationOperationResult> Operations,
    string? Error = null,
    string? Warning = null);
