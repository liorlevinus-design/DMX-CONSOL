namespace DmxConsole.NaturalLanguageDraft;

public enum InterpretationStatus
{
    Ready,
    NeedsClarification,
    Rejected
}

public sealed record ClarificationRequest(
    string Reason,
    IReadOnlyList<TargetCandidate> Candidates,
    string? SuggestedQuestion = null);

public sealed record InterpretationResult
{
    public required InterpretationStatus Status { get; init; }
    public IReadOnlyList<ConsoleCommandEnvelope> Commands { get; init; } = Array.Empty<ConsoleCommandEnvelope>();
    public ClarificationRequest? Clarification { get; init; }
    public string? Error { get; init; }
    public string? SourceUtterance { get; init; }
}
