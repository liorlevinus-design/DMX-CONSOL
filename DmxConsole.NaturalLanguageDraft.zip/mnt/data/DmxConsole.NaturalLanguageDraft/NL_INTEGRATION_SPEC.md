# DmxConsole Natural-Language Programmer — Integration Draft v0.1

## Goal

Translate theatre/dance lighting language into explicit semantic console commands. The NL layer is a client of `DmxConsole.Application`; it never writes DMX, never mutates Core objects directly, and never becomes the source of truth for console state.

## Architectural boundary

```text
Voice / Text
    ↓
NL Interpreter + conversational context
    ↓
Target resolution / ambiguity handling
    ↓
Structured semantic commands
    ↓
DmxConsole.Application (CommandDispatcher / Services)
    ↓
DmxConsole.Core
    ↓
DMX engine / protocols
```

## Core rules

1. **Explicit before execution.** Natural language must be converted to an explicit command envelope before dispatch.
2. **No guessing on ambiguous targets.** If `ווש קר` resolves to more than one group, return candidates and ask for clarification.
3. **Console state and language context are different.** Selection/Programmer/Cues live in Application/Core. Pronouns and conversational references (`אותם`, `עוד 10`) live only in the NL layer.
4. **Absolute and relative values are different operations.** `שים פרונטים על 20` = absolute 20%. `תעלה פרונטים ב-20` = relative +20 percentage points.
5. **One utterance should normally become one transaction.** Multi-action utterances dispatch as a batch so one Undo can revert the whole instruction.
6. **Application results are authoritative.** The NL response is generated from structured execution results, never from assumptions about what should have happened.

## Example interpretations

### Relative adjustment

User: `תוריד לי את הווש הקר ב-30`

```text
AdjustAttribute
Target = resolved group id for Cold Wash
Attribute = Intensity
Mode = Relative
ValuePercent = -30
```

### Absolute level

User: `שים פרונטים על 40`

```text
SetAttribute
Target = resolved Fronts group
Attribute = Intensity
Mode = Absolute
ValuePercent = 40
```

### Context continuation

User: `תבחר את הפרונטים`

NL context records resolved target Fronts after successful execution.

User: `עוד 10`

Interpret as relative `+10` only when the prior target/attribute are unambiguous. Otherwise ask a clarification question.

### Cue operation

User: `שמור כקיו 17, אין 8 אאוט 13`

```text
Batch
  StoreCue(cue=17)
  SetCueTiming(cue=17, fadeIn=8, fadeOut=13)
```

Whether timing is passed inside `StoreCueCommand` or as a second command should follow the final Application API; the NL contract can support either.

## Target resolution priority

1. Exact show-specific canonical name.
2. Exact show-specific alias.
3. Existing current selection/context when the utterance is referential (`אותם`, `אלה`).
4. Common lighting vocabulary alias.
5. Fuzzy search candidates returned by Application.
6. If more than one meaningful candidate remains: clarification, never auto-select.

## Seed Hebrew lighting vocabulary

- `פרונטים`, `פרונט` → Fronts
- `ווש קר` → Cold Wash
- `שטיפה קרה` → Cold Wash
- `שטיפה אחורית קרה` → Cold Back Wash
- `ווש חם` → Warm Wash
- `בק`, `בק לייט` → Backlight
- `ספיישל`, `ספיישלים` → Special(s)
- `בומים` → Booms
- `רצפה` → Floor
- `דימר`, `אינטנסיטי`, `עוצמה` → Intensity
- `פוזישן`, `מיקום` → Position
- `צבע` → Color
- `בים`, `אלומה` → Beam

This is only a seed lexicon. Show-specific names always win.

## Required Application capabilities

The NL adapter eventually needs these stable capabilities from `DmxConsole.Application`:

- Search groups/fixtures/presets by text and return **all** meaningful matches with stable IDs.
- Dispatch one semantic command.
- Dispatch a batch atomically.
- Undo/Redo.
- Structured command results, including child results for Batch.
- Query current selection and current Programmer state when needed for interpretation/confirmation.

## Ambiguity example

Existing groups:

- Cold Wash Floor
- Cold Wash Truss

User: `תוריד את הווש הקר`

Result must be `NeedsClarification` with both candidates. A suggested response is: `איזה ווש קר — Floor או Truss?`

## Safety rule for destructive/broad actions

Ordinary level and selection changes can execute directly. Commands that affect a very broad scope, delete stored data, overwrite cues/presets, or have unresolved targets should be eligible for preview/confirmation policy before execution. The confirmation policy should remain outside Core.

## Next implementation step after Claude finishes C0

Create a real `DmxConsole.NaturalLanguage` project referencing `DmxConsole.Application`, replace `IConsoleApplicationBridge` with an adapter over the actual C0 API, then implement:

1. target resolver,
2. rule-based Hebrew parser for the first safe command subset,
3. context resolver,
4. ambiguity flow,
5. unit-test corpus,
6. later: speech-to-text and LLM function calling.
